1.0.0
===
- Base functionality and illustrations
- Create a new post when bashing one out
- Load previously-saved posts
- Client side countdown timer